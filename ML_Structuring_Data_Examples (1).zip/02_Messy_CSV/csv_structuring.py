import pandas as pd
from sklearn.preprocessing import LabelEncoder

df = pd.read_csv("student_scores.csv")

df.columns = df.columns.str.strip()
df['Name'] = df['Name'].str.strip()
df['Gender'] = df['Gender'].str.strip()
df['Passed'] = df['Passed'].str.strip()

df['Age'] = pd.to_numeric(df['Age'], errors='coerce')
df['Age'].fillna(df['Age'].mean(), inplace=True)
df['Score'] = pd.to_numeric(df['Score'], errors='coerce')
df['Score'].fillna(df['Score'].median(), inplace=True)
df['Gender'].fillna(df['Gender'].mode()[0], inplace=True)

le = LabelEncoder()
df['Gender'] = le.fit_transform(df['Gender'])
df['Passed'] = le.fit_transform(df['Passed'])

print(df)
