from bs4 import BeautifulSoup
import pandas as pd

with open("products.html", "r", encoding="utf-8") as f:
    soup = BeautifulSoup(f, "html.parser")

products = soup.find_all("div", class_="product")

records = []
for product in products:
    title = product.find("h2", class_="title").text.strip()
    price = product.find("span", class_="price").text.strip().replace("₹", "")
    rating = product.find("span", class_="rating").text.strip()
    records.append({
        'Product': title,
        'Price (INR)': int(price),
        'Rating': float(rating)
    })

df = pd.DataFrame(records)
print(df)
