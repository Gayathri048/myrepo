import pandas as pd
import re

with open("access.log") as file:
    lines = file.readlines()

records = []
for line in lines:
    match = re.search(r"\[(.*?)\] (\w+): User=(\w+) Action=(\w+) Status=(\w+)", line)
    if match:
        dt, level, user, action, status = match.groups()
        records.append({
            'DateTime': dt,
            'Level': level,
            'User': user,
            'Action': action,
            'Status': status
        })

df = pd.DataFrame(records)
print(df)
